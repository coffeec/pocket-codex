export { default } from './PRDEditor';
